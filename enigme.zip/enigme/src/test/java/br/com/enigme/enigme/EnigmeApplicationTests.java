package br.com.enigme.enigme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnigmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
