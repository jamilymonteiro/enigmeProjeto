package br.com.enigme.enigme.service;

import br.com.enigme.enigme.entity.Pagamento;
import br.com.enigme.enigme.repository.PagamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class PagamentoService {
    @Autowired
    private PagamentoRepository pagamentoRepository;

    public Iterable<Pagamento> listarTodos() {
        return pagamentoRepository.findAll();
    }

    public ResponseEntity<Pagamento> salvar(Pagamento cartao) {
        return new ResponseEntity<>(pagamentoRepository.save(cartao), HttpStatus.OK);
    }

    public ResponseEntity<Pagamento> buscarPorId(Long id) {
        return new ResponseEntity<>(pagamentoRepository.findById(id).orElseThrow(), HttpStatus.OK);
    }

    public ResponseEntity<String> deletar(Long id) {
        pagamentoRepository.deleteById(id);
        return new ResponseEntity<>("{\"mensagem\":\"Removido com sucesso\"}", HttpStatus.OK);
    }


}