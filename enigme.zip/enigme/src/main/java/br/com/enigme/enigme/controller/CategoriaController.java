package br.com.enigme.enigme.controller;

import br.com.enigme.enigme.entity.Categoria;
import br.com.enigme.enigme.service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/categoria")
public class CategoriaController {


}
